/*
 *
 * Copyright 2010 of 3D for All Ltd. (www.Leonar3Do.com). 
 *
 * Warning! This document is an integral and inseparable part of the 
 * Leonar3Do Software Development Kit version: 1.0., protected by the 
 * Copyright 2010 of 3D for All Ltd. (www.Leonar3Do.com). 
 * All rights are reserved. Unauthorized reproduction or distribution 
 * of Leonar3Do Software Development Kit version: 1.0., or any portion 
 * of it, may result in severe civil and criminal penalties, and will 
 * be prosecuted to the maximum extent possible under the governing law 
 * specified it in the �License Terms for 3D for All Ltd.�s Leonar3Do 
 * Software Development Kit version: 1.0�. 
 *
 */

#include <GL/freeglut.h>
#include <LeoAPI.h>


// ------------------------------------------------------------------------
//  globals
// ------------------------------------------------------------------------

double bird_pos[3];             // bird position
double bird_rot[3];             // bird rotation
bool small_button_pressed;      // small button state
double big_button_pression;     // big button state
LGLContext lgl_ctx;             // an LGL context


bool Initialize()
{
    // initialize and connect the application to Leonar3Do System Software
    if (!leoInitialize())
    {
        return false;
    }

    // initialize LGL
    lglInitialize();

    // create an LGL context 
    // (with the currently active OpenGL rendering context and its device)
    lgl_ctx = lglCreateContext(NULL, NULL);
    if (!lgl_ctx)
    {
        return false;
    }

    // other initializations
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // init OpenGL lights
    const float ambient[] = { 0.2f, 0.2f, 0.2f, 1.0f };
    const float diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    const float specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    const float pos[] = { 1.0f, 1.0f, 1.0f, 0.0f };
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, pos);

    return true;
}


void CleanUp()
{
    leoSetStereo(false);
    lglDeleteContext(lgl_ctx);
}


void UpdateLeoInfo()
{
    // get info from LeoAPI
    leoGetBirdPosition(bird_pos, bird_pos + 1, bird_pos + 2,
                       bird_rot, bird_rot + 1, bird_rot + 2);
    small_button_pressed = leoGetSmallButtonState();
    big_button_pression = leoGetBigButtonState();

    glClearColor(float(big_button_pression), 0.0f, 0.0f, 1.0f);
    leoSetBirdVibration(big_button_pression);
}


inline double RadToDeg(double x)
{
    const double _180_PER_PI = 57.295779513082320876798154814105;
    return x * _180_PER_PI;
}


void DrawBird()
{
    const double sphere_radius = 0.04;
    const double cylinder_radius = 0.01;
    const double cylinder_height = 0.16;
    const double half_cylinder_height = 0.5 * cylinder_height;
    const int slices = 32;
    const int stacks = 32;

    const float sphere_color_normal[] = { 0.6f, 0.8f, 1.0f, 1.0f };
    const float sphere_specular_color_normal[] = { 0.6f, 0.8f, 1.0f, 1.0f };
    const float sphere_color_clicked[] = { 0.6f, 1.0f, 0.8f, 1.0f };
    const float sphere_specular_color_clicked[] = { 0.6f, 1.0f, 0.8f, 1.0f };
    const float sphere_shininess = 20.0f;

    const float cylinder_color_normal[] = { 1.0f, 0.4f, 0.2f, 1.0f };
    const float cylinder_specular_color_normal[] = { 1.0f, 0.4f, 0.2f, 1.0f };
    const float cylinder_color_clicked[] = { 0.4f, 0.2f, 1.0f, 1.0f };
    const float cylinder_specular_color_clicked[] = { 0.4f, 0.2f, 1.0f, 1.0f };
    const float cylinder_shininess = 50.0f;

    const float* sphere_color;
    const float* sphere_specular_color;
    const float* cylinder_color;
    const float* cylinder_specular_color;

    if (small_button_pressed)
    {
        sphere_color = sphere_color_clicked;
        sphere_specular_color = sphere_specular_color_clicked;
        cylinder_color = cylinder_color_clicked;
        cylinder_specular_color = cylinder_specular_color_clicked;
    }
    else
    {
        sphere_color = sphere_color_normal;
        sphere_specular_color = sphere_specular_color_normal;
        cylinder_color = cylinder_color_normal;
        cylinder_specular_color = cylinder_specular_color_normal;
    }

    glPushMatrix(); 
    
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, sphere_color);
    glMaterialfv(GL_FRONT, GL_SPECULAR, sphere_specular_color);
    glMaterialf(GL_FRONT, GL_SHININESS, sphere_shininess);

    glTranslated(bird_pos[0], bird_pos[1], bird_pos[2]);
    glRotated(RadToDeg(bird_rot[2]), 0.0, 0.0, 1.0);
    glRotated(RadToDeg(bird_rot[1]), 0.0, 1.0, 0.0);
    glRotated(RadToDeg(bird_rot[0]), 1.0, 0.0, 0.0);
    
    glutSolidSphere(sphere_radius, slices, stacks);

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, cylinder_color);
    glMaterialfv(GL_FRONT, GL_SPECULAR, cylinder_specular_color);
    glMaterialf(GL_FRONT, GL_SHININESS, cylinder_shininess);

    glTranslated(0.0, 0.0, -half_cylinder_height);
    glutSolidCylinder(cylinder_radius, cylinder_height, slices, stacks);
    glTranslated(0.0, 0.0, half_cylinder_height);

    glRotated(90.0, 0.0, 1.0, 0.0);
    glTranslated(0.0, 0.0, -half_cylinder_height);
    glutSolidCylinder(cylinder_radius, cylinder_height, slices, stacks);

    glPopMatrix();
}


void Frame()
{
    // retrieve current bird state
    UpdateLeoInfo();

    // get the number of views to render
    int rc = lglGetRenderCount(lgl_ctx);

    // iterate through the views
    for (int i = 0; i < rc; ++i)
    {
        // start render the ith view
        double projmat[16];
        lglStartRender(lgl_ctx, i, projmat);

        // set the projection matrix associated with the current view
        glMatrixMode(GL_PROJECTION);
        glLoadMatrixd(projmat);

        // render the scene
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        
        DrawBird();
    }

    // indicate that all rendering is finished
    lglFinishRender(lgl_ctx);
}


void Key(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 32:    // SPACE key
            leoSetStereo(!leoIsStereoSwitchedOn());
            break;

        case 27:    // ESC key
            CleanUp();
            glutLeaveMainLoop();
            break;
    }
}


void Idle()
{
    glutPostRedisplay();
}


void Display()
{
    Frame();
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

    glutInitWindowPosition(200, 200);
    glutInitWindowSize(800, 600);
    glutCreateWindow("LeoAPI Sample");

    glutKeyboardFunc(Key);
    glutDisplayFunc(Display);
    glutIdleFunc(Idle);

    if (!Initialize())
    {
        return -1;
    }

    glutMainLoop();

    return 0;   // avoid a compiler warning
}
